import { scrapeRecipe } from "@/lib/scraper";
import { supabase } from "@/lib/supabase";
import { redirect } from "next/navigation";

export async function GET(request) {
  const { searchParams } = new URL(request.url);

  // The shared URL can arrive in ?url= or hidden inside ?text=
  let sharedUrl =
    searchParams.get("url") ??
    searchParams.get("text")?.match(/https?:\/\/[^\s]+/)?.[0];

  if (!sharedUrl) {
    redirect("/?error=no-url");
  }

  const result = await scrapeRecipe(sharedUrl);

  if (!result.success) {
    redirect(`/?error=scrape-failed`);
  }

  const { data, source } = result;

  const { data: saved, error } = await supabase
    .from("recipes")
    .insert([
      {
        title: data.title,
        description: data.description,
        image: data.image,
        ingredients: data.ingredients,
        steps: data.steps,
        time: data.time,
        servings: data.servings,
        category: data.category,
        source_url: data.source_url,
        source_name: data.source_name,
        raw_text: data.raw_text ?? null,
        parse_status: source, // "schema" or "fallback"
      },
    ])
    .select()
    .single();

  if (error) {
    redirect(`/?error=save-failed`);
  }

  // Redirect to the new recipe so user sees it immediately
  redirect(`/recipe/${saved.id}?new=1`);
}
